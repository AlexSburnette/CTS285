//<editor-fold defaultstate="collapsed" desc="BlockComment">
/*
* CTS 285
* Dataman
* In Collaberation of Alexander Burnette, Zachary Fegan, and Garrett Davis
* last updated 10-20-2021
*/
//</editor-fold>
package dataman;
import java.util.Scanner;
import java.util.Random;


public class Dataman {
    public static Question[] questions = new Question[0];

    //<editor-fold defaultstate="collapsed" desc="Main">
    public static void main(String[] args)
    {
        menu();
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="MainMenu">
    public static void menu()
    {
        int input;
        Scanner keyboard = new Scanner(System.in);
        System.out.println("DATAMAN"
                + "\n~~~~~~~~~~~~~~~"
                + "\nMake a selection!");
        System.out.println("1. Answer Checker"
                + "\n2. Memory Bank"
                + "\n3. Number Guesser"
                + "\n4. Exit");
        input=keyboard.nextInt();
        switch (input)
        {
            case 1:
                checker();
                break;
            case 2:
                memBank();
                break;
            case 3:
                numGuess();
                break;
            case 4:
                if(input == 4)
                {
                    // Closes the program
                    System.out.print("GoodBye!");
                    System.exit(4);
                }
                break;
            default:
                System.out.println("Choose between 1-4.");
                menu();
                break;
        }
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="checker">
    public static void checker()
    {
        Scanner keyboard = new Scanner (System.in);
        int number;
        System.out.println("Welcome to the Answer Checker!");
        System.out.println("Which would you like to do?"
                + "\n1. Addtion"
                + "\n2. Subtraction"
                + "\n3. Multiplication"
                + "\n4. Division"
                + "\n5. Main Menu");
        number=keyboard.nextInt();
        switch (number)
        {
            case 1:
                Additionchecker();
                /* This is a a preview of implementation of the math class
                /
                System.out.println("Enter the first number: ");
                double num1 = keyboard.nextDouble();
                System.out.println("Enter the second number: ");
                double num2 = keyboard.nextDouble();
                double results = Math.AddNumbers(num1, num2);
                boolean tryAgain = true;
                do
                {
                    System.out.println("What do you think the answser is?");
                    double guess = keyboard.nextDouble();
                    if(CompareNumbers(guess, results) == true)
                {
                System.out.println("Great job, you've entered the correct "
                + "number1");
                tryAgain = false;
                }
                else if(CompareNumbers(guess, results) == false)
                    {
                        System.out.print("You've entered an incorrect guess");
                        System.out.print("Would you like to try again?(y/n) ");
                        String entry = keyboard.toString();
                        if(entry.equals("y") || entry.equals("yes"))
                        {
                            tryAgain = true;
                        }
                        else
                        {
                            tryAgain = false;
                        }
                    }
                }
                while(tryAgain == true);*/
                break;
            case 2:
                
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                menu();
                break;
            default:
                System.out.println("Choose between 1-5.");
                checker();
                break;
        }
    }
    
    //<editor-fold defaultstate="collapsed" desc="AdditionChecker">
    public static void Additionchecker()
    {
        
    }
    //</editor-fold>
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="memoryBank">
    public static void memBank()
    {   
        System.out.println("Welcome to the memory bank! What would you like to do?");
        System.out.println("1. Input Questions");
        System.out.println("2. Answer Questions");
        System.out.println("3. Main Menu");
        Scanner keyboard = new Scanner(System.in);
        int decision = keyboard.nextInt();
        switch(decision){
            case 1: GetQuestions();
            break;
            case 2: if (questions.length > 0)
                    {AnswerQuestions();}
                    else {System.out.println("No questions created yet.");
                          memBank();}
            case 3: menu();
            default : System.out.println("Incorrect input");
        }
        System.out.println("What would you like to do?");
        System.out.println("1. MemBank Menu");
        System.out.println("2. MainMenu");
        decision = keyboard.nextInt();
        switch(decision){
            case 1: memBank();
            case 2: menu();
            default: System.out.println("Incorrect input, returning to main");
        }
    }
    
    //<editor-fold defaultstate="collapsed" desc="memAddition">
    public static void memAddition(double num1, double num2, double correctTotal)
    {
        Scanner scnr = new Scanner(System.in);
        double userTotal;
        
        System.out.print(num1 + " + " + num2 + " = ? ");
        userTotal = scnr.nextDouble();
        
        if(userTotal == correctTotal)
        {
            System.out.println("Correct!");
        }
        else
        {
            System.out.println("Incorrect!");
        }
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="memSubtraction">
    public static void memSubtraction(double num1, double num2, double correctTotal)
    {
        Scanner scnr = new Scanner(System.in);
        double userTotal;
        
        System.out.print(num1 + " - " + num2 + " = ? ");
        userTotal = scnr.nextDouble();
        
        if(userTotal == correctTotal)
        {
            System.out.println("Correct!");
        }
        else
        {
            System.out.println("Incorrect!");
        }
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="memDivision">
    public static void memDivision(double num1, double num2, double correctTotal)
    {
        Scanner scnr = new Scanner(System.in);
        double userTotal;
        
        System.out.print(num1 + " / " + num2 + " = ? ");
        userTotal = scnr.nextDouble();
        
        if(userTotal == correctTotal)
        {
            System.out.println("Correct!");
        }
        else
        {
            System.out.println("Incorrect!");
        }
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="memMultiplication">
    public static void memMultiplication(double num1, double num2, double correctTotal)
    {
        Scanner scnr = new Scanner(System.in);
        double userTotal;
        
        System.out.print(num1 + " * " + num2 + " = ? ");
        userTotal = scnr.nextDouble();
        
        if(userTotal == correctTotal)
        {
            System.out.println("Correct!");
        }
        else
        {
            System.out.println("Incorrect!");
        }
    }
    //</editor-fold>
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="numGuess">
    public static void numGuess()
    {
        Scanner keyboard = new Scanner(System.in);
        Random rand = new Random();
        final int min = 9;
        final int max = 100;
        int numberGuess = 0;
        int input=0;
        int answer=0;
        int guess=0;
        answer=rand.nextInt(max)+1;
        System.out.println("Welcome to Number Guesser!"
                + "\n------------------------------"
                + "\n1. Start"
                + "\n2. Main Menu");
        input=keyboard.nextInt();
        switch (input)
        {
            case 1:
                System.out.println("Can you figure out the number?");
                System.out.println("Enter the number");
                 guess = keyboard.nextInt();
                while( guess != answer)
                { 
                    numberGuess++;
                    if(guess <min || guess>max)
                    {
                        System.out.println("Choose a number between 9-100");
                        
                    }
                    else if(guess > answer)
                            {
                              System.out.println("You are to high!");
                            }
                    else if(guess < answer)
                    {
                        System.out.println("You are too low!");
                    }
                   System.out.println("Enter the number");
                   guess = keyboard.nextInt();
                }
                System.out.println("You found the number "+answer+ " in "+numberGuess+".");
               break;
            case 2:
                menu();
                break;
            default:
                break;
        }
    }
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Compare Nums">
    public static boolean CompareNumbers(double guess, double answer)
    {
        boolean results = true;
        if(guess != answer)
        {
            results = false;
        }
        return results;
    }
    //</editor-fold>
    public static void GetQuestions()
    {
        Scanner keyboard = new Scanner(System.in);
        int inputX;
        int inputY;
        int answer;
        int counter = 0;
        do {
        System.out.println("How many questions would you like to input? (Max 10)");
        counter = keyboard.nextInt();}
        while(counter > 10 || counter == 0);
        questions = new Question[counter];
        int i;
        for(i = 0; i < counter; i++)
        {   
            System.out.println("What type of question would you like to make?");
            System.out.println("1. Addition");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4. Division");
            int decision = keyboard.nextInt();
            switch (decision){
                case 1: System.out.println("Input the first number: ");
                        inputX = keyboard.nextInt();
                        System.out.println("Input the second number: ");
                        inputY= keyboard.nextInt();
                        answer = inputX + inputY;
                        questions[i] = new Question(inputX, "+", inputY, answer);
                        break;
                case 2: System.out.println("Input the first number: ");
                        inputX = keyboard.nextInt();
                        System.out.println("Input the second number: ");
                        inputY= keyboard.nextInt();
                        answer = inputX - inputY;
                        questions[i] = new Question(inputX, "-", inputY, answer);
                        break;
                case 3: System.out.println("Input the first number: ");
                        inputX = keyboard.nextInt();
                        System.out.println("Input the second number: ");
                        inputY= keyboard.nextInt();
                        answer = inputX * inputY;
                        questions[i] = new Question(inputX, "*", inputY, answer);
                        break;
                case 4: System.out.println("Input the first number: ");
                        inputX = keyboard.nextInt();
                        System.out.println("Input the second number: ");
                        inputY= keyboard.nextInt();
                        answer = inputX / inputY;
                        questions[i] = new Question(inputX, "/", inputY, answer); 
                        break;
                default:System.out.println("Incorrect input. Please input 1-4");
            }
        }
        System.out.println("Questions Created!");
       
    }
    public static void AnswerQuestions()
    {
        Scanner keyboard = new Scanner(System.in);
        int i;
        int counter = 0;
        for (i = 0; i < questions.length; i++)
        {
           System.out.println("Input the correct answer for each question.");
           System.out.println(questions[i].inputX + questions[i].math + questions[i].inputY);
           int answer = keyboard.nextInt();
           if (answer == questions[i].answer)
           {System.out.println("Correct!");
           counter++;}
           else{System.out.println("Incorrect.");}
        }
        System.out.println("You've answered " + counter + " questions out of " 
        + questions.length + " correctly");

    }
    
    
}
