//<editor-fold defaultstate="collapsed" desc="BlockComment">
/*
* CTS 285
* Dataman
* In Collaberation of Alexander Burnette, Zachary Fegan, and Garrett Davis
* Final Iteration
* last updated 10/31/2021
*/
//</editor-fold>
package dataman;
import java.util.Scanner;
import java.util.Random;


public class Dataman {
    public static Question[] questions = new Question[0];

    //<editor-fold defaultstate="collapsed" desc="Main">
    public static void main(String[] args)
    {
        menu();
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="MainMenu">
    public static void menu()
    {
        int input;
        Scanner keyboard = new Scanner(System.in);
        System.out.println("DATAMAN"
                + "\n~~~~~~~~~~~~~~~"
                + "\nMake a selection!");
        System.out.println("1. Answer Checker"
                + "\n2. Memory Bank"
                + "\n3. Number Guesser"
                + "\n4. Calculator"
                + "\n5. Exit");
        input=keyboard.nextInt();
        switch (input)
        {
            case 1:
                checker();
                break;
            case 2:
                memBank();
                break;
            case 3:
                numGuess();
                break;
            case 4:
                cal();
                break;
            case 5:
                System.out.println("Goodbye!");
                System.exit(0);
            default:
                System.out.println("Choose between 1-4.");
                menu();
                break;
        }
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="checker">
    public static void checker()
    {
        String tryAgain = "yes";
        Scanner keyboard = new Scanner (System.in);
        int number;
        do{
        System.out.println("Welcome to the Answer Checker!");
        System.out.println("Which would you like to do?"
                + "\n1. Addition"
                + "\n2. Subtraction"
                + "\n3. Multiplication"
                + "\n4. Division"
                + "\n5. Main Menu");
        number=keyboard.nextInt();
        switch (number)
        {
            case 1:
                tryAgain = AdditionChecker();
                break;
            case 2:
                tryAgain = SubtractionChecker();
                break;
            case 3:
                tryAgain = MultiplicationChecker();
                break;
            case 4:
                tryAgain = DivisionChecker();
                break;
            case 5:
                menu();
                break;
            default:
                System.out.println("Choose between 1-5.");
                checker();
                break;
        }
        }
        while(tryAgain.equalsIgnoreCase("yes"));
        menu();
    }
    
    //<editor-fold defaultstate="collapsed" desc="AdditionChecker">
    public static String AdditionChecker()
    {
        int i;
        String tryAgain;
        Scanner scnr = new Scanner(System.in);
        System.out.println("-------Addition!-------");
        System.out.println("Input first number: ");
        int x = scnr.nextInt();
        System.out.println("Input second number: ");
        int y = scnr.nextInt();
        int ans = x + y;
        System.out.println("Input the answer: ");
        System.out.println(x + " + " + y + " = ");
        int input = scnr.nextInt();
        if(input == ans)
        {
            System.out.println("Correct!");
            System.out.println("Go again?");
            tryAgain = scnr.next();
        }
        else
        {
            System.out.println("EEE");
            System.out.println("incorrect");
            System.out.println("Go again?");    
            tryAgain = scnr.next();
        }
        return tryAgain;
    }
    public static String SubtractionChecker()
    {
        int i;
        String tryAgain;
        Scanner scnr = new Scanner(System.in);
        System.out.println("-------Subtraction!-------");
        System.out.println("Input first number: ");
        int x = scnr.nextInt();
        System.out.println("Input second number: ");
        int y = scnr.nextInt();
        int ans = x - y;
        System.out.println("Input the answer: ");
        System.out.println(x + " - " + y + " = ");
        int input = scnr.nextInt();
        if(input == ans)
        {
            System.out.println("Correct!");
            System.out.println("Go again?");
            tryAgain = scnr.next();
        }
        else
        {
            System.out.println("EEE");
            System.out.println("incorrect");
            System.out.println("Go again?");    
            tryAgain = scnr.next();
        }
        return tryAgain;
    }
    public static String MultiplicationChecker()
    {
        int i;
        String tryAgain;
        Scanner scnr = new Scanner(System.in);
        System.out.println("-------Multiplication!-------");
        System.out.println("Input first number: ");
        int x = scnr.nextInt();
        System.out.println("Input second number: ");
        int y = scnr.nextInt();
        int ans = x * y;
        System.out.println("Input the answer: ");
        System.out.println(x + " * " + y + " = ");
        int input = scnr.nextInt();
        if(input == ans)
        {
            System.out.println("Correct!");
            System.out.println("Go again?");
            tryAgain = scnr.next();
        }
        else
        {
            System.out.println("EEE");
            System.out.println("incorrect");
            System.out.println("Go again?");    
            tryAgain = scnr.next();
        }
        return tryAgain;
    }
    public static String DivisionChecker()
    {
        int i;
        String tryAgain;
        Scanner scnr = new Scanner(System.in);
        System.out.println("-------Division!-------");
        System.out.println("Input first number: ");
        int x = scnr.nextInt();
        System.out.println("Input second number: ");
        int y = scnr.nextInt();
        int ans = x / y;
        System.out.println("Input the answer: ");
        System.out.println(x + " / " + y + " = ");
        int input = scnr.nextInt();
        if(input == ans)
        {
            System.out.println("Correct!");
            System.out.println("Go again?");
            tryAgain = scnr.next();
        }
        else
        {
            System.out.println("EEE");
            System.out.println("incorrect");
            System.out.println("Go again?");    
            tryAgain = scnr.next();
        }
        return tryAgain;
    }
    //</editor-fold>
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="memoryBank">
    public static void memBank()
    {   
        System.out.println("Welcome to the memory bank! What would you like to do?");
        System.out.println("1. Input Questions");
        System.out.println("2. Answer Questions");
        System.out.println("3. Main Menu");
        Scanner keyboard = new Scanner(System.in);
        int decision = keyboard.nextInt();
        switch(decision){
            case 1: GetQuestions();
            break;
            case 2: if (questions.length > 0)
                    {AnswerQuestions();}
                    else {System.out.println("No questions created yet.");
                          memBank();}
            case 3: menu();
            default : System.out.println("Incorrect input");
        }
        System.out.println("What would you like to do?");
        System.out.println("1. MemBank Menu");
        System.out.println("2. MainMenu");
        decision = keyboard.nextInt();
        switch(decision){
            case 1: memBank();
            case 2: menu();
            default: System.out.println("Incorrect input, returning to main");
        }
    }
    
    //<editor-fold defaultstate="collapsed" desc="memAddition">
    public static void memAddition(double num1, double num2, double correctTotal)
    {
        Scanner scnr = new Scanner(System.in);
        double userTotal;
        
        System.out.print(num1 + " + " + num2 + " = ? ");
        userTotal = scnr.nextDouble();
        
        if(userTotal == correctTotal)
        {
            System.out.println("Correct!");
        }
        else
        {
            System.out.println("Incorrect!");
        }
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="memSubtraction">
    public static void memSubtraction(double num1, double num2, double correctTotal)
    {
        Scanner scnr = new Scanner(System.in);
        double userTotal;
        
        System.out.print(num1 + " - " + num2 + " = ? ");
        userTotal = scnr.nextDouble();
        
        if(userTotal == correctTotal)
        {
            System.out.println("Correct!");
        }
        else
        {
            System.out.println("Incorrect!");
        }
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="memDivision">
    public static void memDivision(double num1, double num2, double correctTotal)
    {
        Scanner scnr = new Scanner(System.in);
        double userTotal;
        
        System.out.print(num1 + " / " + num2 + " = ? ");
        userTotal = scnr.nextDouble();
        
        if(userTotal == correctTotal)
        {
            System.out.println("Correct!");
        }
        else
        {
            System.out.println("Incorrect!");
        }
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="memMultiplication">
    public static void memMultiplication(double num1, double num2, double correctTotal)
    {
        Scanner scnr = new Scanner(System.in);
        double userTotal;
        
        System.out.print(num1 + " * " + num2 + " = ? ");
        userTotal = scnr.nextDouble();
        
        if(userTotal == correctTotal)
        {
            System.out.println("Correct!");
        }
        else
        {
            System.out.println("Incorrect!");
        }
    }
    //</editor-fold>
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="numGuess">
    public static void numGuess()
    {
        Scanner keyboard = new Scanner(System.in); 
        Random rand = new Random();
        final int min = 0;
        final int max = 100;
        int numberGuess = 0;
        int input=0;
        int answer=0;
        int guess=0;
        int add;
        int sub;
        String ans;
        System.out.println("Welcome to Number Guesser!"
                + "\n------------------------------"
                + "\n1. Start"
                + "\n2. Main Menu");
        input=keyboard.nextInt();
        switch (input)
        {
            case 1:
                do{
                numberGuess = 0 ;
                Random random = new Random();
                answer = rand.nextInt(max) + 1;
                System.out.println("Can you figure out the number?");
                System.out.println("Enter the number");
                 guess = keyboard.nextInt();
                 add = answer + random.nextInt(10);
                 if (add > 100)
                 {
                     add = 100;
                 }
                 sub = answer - random.nextInt(10);
                 if (sub < 0)
                 {
                     sub = 0;
                 }
                while( guess != answer)
                { 
                    numberGuess++;
                    if(guess <min || guess>max)
                    {
                        System.out.println("Choose a number between 0-100");
                        
                    }
                    else if(guess > answer)
                            {
                              System.out.println("You are to high!");
                              System.out.println("The number is between "+sub+" and "+add+".");
                            }
                    else if(guess < answer)
                    {
                        System.out.println("You are too low!");
                        System.out.println("The number is between "+sub+" and "+add+".");
                    }
                   System.out.println("Enter the number");
                   guess = keyboard.nextInt();
                }
                System.out.println("You found the number "+answer+ " in "+numberGuess+" guess.");

                    System.out.println("Would you like to go again?");
                    ans=keyboard.next();
                }
                while(ans.equalsIgnoreCase("yes"));
                menu();
               break;
            case 2:
                menu();
                break;
            default:
                break;
        }
    }
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Compare Nums">
    public static boolean CompareNumbers(double guess, double answer)
    {
        boolean results = true;
        if(guess != answer)
        {
            results = false;
        }
        return results;
    }
    //</editor-fold>
    public static void GetQuestions()
    {
        Scanner keyboard = new Scanner(System.in);
        int inputX;
        int inputY;
        int answer;
        int counter = 0;
        do {
        System.out.println("How many questions would you like to input? (Max 10)");
        counter = keyboard.nextInt();}
        while(counter > 10 || counter == 0);
        questions = new Question[counter];
        int i;
        for(i = 0; i < counter; i++)
        {   
            System.out.println("What type of question would you like to make?");
            System.out.println("1. Addition");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4. Division");
            int decision = keyboard.nextInt();
            switch (decision){
                case 1: System.out.println("Input the first number: ");
                        inputX = keyboard.nextInt();
                        System.out.println("Input the second number: ");
                        inputY= keyboard.nextInt();
                        answer = inputX + inputY;
                        questions[i] = new Question(inputX, "+", inputY, answer);
                        break;
                case 2: System.out.println("Input the first number: ");
                        inputX = keyboard.nextInt();
                        System.out.println("Input the second number: ");
                        inputY= keyboard.nextInt();
                        answer = inputX - inputY;
                        questions[i] = new Question(inputX, "-", inputY, answer);
                        break;
                case 3: System.out.println("Input the first number: ");
                        inputX = keyboard.nextInt();
                        System.out.println("Input the second number: ");
                        inputY= keyboard.nextInt();
                        answer = inputX * inputY;
                        questions[i] = new Question(inputX, "*", inputY, answer);
                        break;
                case 4: System.out.println("Input the first number: ");
                        inputX = keyboard.nextInt();
                        System.out.println("Input the second number: ");
                        inputY= keyboard.nextInt();
                        answer = inputX / inputY;
                        questions[i] = new Question(inputX, "/", inputY, answer); 
                        break;
                default:System.out.println("Incorrect input. Please input 1-4");
            }
        }
        System.out.println("Questions Created!");
       
    }
    public static void AnswerQuestions()
    {
        Scanner keyboard = new Scanner(System.in);
        int i;
        int counter = 0;
        for (i = 0; i < questions.length; i++)
        {
           System.out.println("Input the correct answer for each question.");
           System.out.println(questions[i].inputX + questions[i].math + questions[i].inputY);
           int answer = keyboard.nextInt();
           if (answer == questions[i].answer)
           {System.out.println("Correct!");
           counter++;}
           else{System.out.println("Incorrect.");}
        }
        System.out.println("You've answered " + counter + " questions out of " 
        + questions.length + " correctly");

    }
    //<editor-fold defaultstate="collapsed" desc="Calculator">
    public static void cal()
    {
        int input;
        int num1;
        int num2;
        double num3;
        double num4;
        double tot;
        int total;
        String ans = "yes";
        do{
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Welcome to the Calculator."
                + "\n1. Add"
                + "\n2. Subtract"
                + "\n3. Multiply"
                + "\n4. Divide"
                + "\n5. Menu");
        System.out.print("Enter your Number: ");
        input=keyboard.nextInt();
        switch(input)
        {
            case 1:
                System.out.println("Welcome to Addition!"
                        + "\n Choose your first number!");
                num1=keyboard.nextInt();
                System.out.println("Enter yout second!");
                num2=keyboard.nextInt();
                total=num1+num2;
                System.out.println(num1+"+"+num2+"="+total);
                System.out.println("Would you like to go again?");
                ans=keyboard.next();
                break;
            case 2:

                System.out.println("Welcome to Subtraction!"
                        + "\n Choose your first number!");
                num1=keyboard.nextInt();
                System.out.println("Enter yout second!");
                num2=keyboard.nextInt();
                total=num1-num2;
                System.out.println(num1+"-"+num2+"="+total);
                System.out.println("Would you like to go again?");
                ans=keyboard.next();
                break;
            case 3:

                System.out.println("Welcome to Mulitplication!"
                        + "\n Choose your first number!");
                num1=keyboard.nextInt();
                System.out.println("Enter yout second!");
                num2=keyboard.nextInt();
                total=num1*num2;
                 System.out.println(num1+"*"+num2+"="+total);
                System.out.println("Would you like to go again?");
                ans=keyboard.next();

                break;
                
            case 4:

                System.out.println("Welcome to Division!"
                        + "\n Choose your first number!");
                num1=keyboard.nextInt();
                System.out.println("Enter yout second!");
                num2=keyboard.nextInt();
                total=num1/num2;
                 System.out.println(num1+"/"+num2+"="+total);
                System.out.println("Would you like to go again?");
                ans=keyboard.next();
                break;
            case 5:
                menu();
                break;
            default:
                System.out.println("Choose between 1-5.");
                cal();
                break;
        }
        }
        while(ans.equalsIgnoreCase("yes"));
        menu();
//</editor-fold>
    }
    
}
