/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataman;

/**
 *
 * @author feganz5140
 */

public class Question {
    int inputX;
    int inputY;
    String math;
    int answer;
    public Question(int inputX, String math,int inputY, int answer)
    {
        this.inputX = inputX;
        this.inputY = inputY;
        this.math = math;
        this.answer = answer;
    }
             
}
