/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataman;

/**
 *
 * @author feganz5140
 */

public class Question {
    int inputX;
    int inputY;
    String math;
    public Question(int inputX, String math,int inputY)
    {
        this.inputX = inputX;
        this.inputY = inputY;
        this.math = math;
    }
    //Create question.
    public static Question[] CreateQuestion(String[] questionsArray)
    {
        char[] input = new char[3];
        Question[] questions = new Question[3];
        int i;
        for (i = 0; i < questionsArray.length; i++)
        {
            input[0] = questionsArray[i].charAt(0);
            input[1] = questionsArray[i].charAt(1);
            input[2] = questionsArray[i].charAt(2);            
            int inputX = Integer.parseInt(String.valueOf(input[0]));
            int inputY = Integer.parseInt(String.valueOf(input[2]));
            String math = String.valueOf(input[1]);
            Question question = new Question(inputX, math, inputY);
            questions[i] = question;
        }
        return questions;
    }
    
            
}
